package com.stackroute.giphermanager.exception;

public class GipherAlreadyExistException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public GipherAlreadyExistException(String message) {
		super(message);
	}
	

}
