package com.stackroute.giphermanager.exception;

public class GipherNotAddedException extends Exception {
	
	private static final long serialVersionUID = 1L;
	public GipherNotAddedException(String message) {
        super(message);
    }

}
