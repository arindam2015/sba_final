package com.stackroute.giphermanager.exception;

public class GipherNotFounfException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public GipherNotFounfException(String message) {
		super(message);
	}
	
	
	
	

}
